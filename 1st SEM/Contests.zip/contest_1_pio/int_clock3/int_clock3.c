#include <stdio.h>

int main()
	{
	int h1, m1, mm;
	scanf("%d %d", &h1, &m1);
	mm = 60*h1 + m1;
	printf("%d", mm);
	}
