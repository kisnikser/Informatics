#include <stdio.h>

int main()
	{
	int res;
	double s, w, ch;
	scanf("%lf %lf %lf", &s, &w, &ch);
	res = s/w/ch;
	printf("%d", res);
	}
