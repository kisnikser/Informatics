#include <stdio.h>

int main()
	{
	int n;
	float k;
	scanf("%d%f", &n, &k);
	printf("%d", (int)((1-k)*n));
	}
