#include <stdio.h>

int main()
{
	int x;
	scanf("%d", &x);
	(x<37 || x>=146) ? printf("YES") : printf("NO");
}
