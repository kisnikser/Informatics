#include <stdio.h>

int main()
{
	int x;
	scanf("%d", &x);
	(x>=-25 && x<37) ? printf("YES") : printf("NO");
}
